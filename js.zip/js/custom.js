var mixer = mixitup('.mix', {
    selectors: {
        target: '.item'
    },
    animation: {
        duration: 300
    }
});